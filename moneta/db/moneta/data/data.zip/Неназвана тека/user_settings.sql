INSERT INTO user_settings (id, def_currency, is_activated)
VALUES
    (1, 1, 1),
    (2, 2, 1),
    (3, 3, 1),
    (4, 4, 1),
    (5, 1, 1),
    (6, 3, 1),
    (7, 4, 1),
    (8, 3, 1),
    (9, 1, 1);
