INSERT INTO currencies (id, currency)
VALUES (1, 'UAH'),
       (2, 'GBP'),
       (3, 'USD'),
       (4, 'EUR');
