INSERT INTO auth_user (id, user_id, password, email, last_login)
VALUES(1, 1, 'pbkdf2_sha256$120000$ybnEf26FolQ7$uAlyyV1CK0jE9TgxTuYnUEp9qdgabvueEtcF51/+Y/M=' ,'shotatam@gmail.com',  NULL),
      (2, 2, 'pbkdf2_sha256$120000$ybnEf26FolQ7$uAlyyV1CK0jE9TgxTuYnUEp9qdgabvueEtcF51/+Y/M=' ,'2@gmail.com',  NULL),
      (3, 3, 'pbkdf2_sha256$120000$ybnEf26FolQ7$uAlyyV1CK0jE9TgxTuYnUEp9qdgabvueEtcF51/+Y/M=' ,'3@gmail.com',  NULL),
      (4, 4, 'pbkdf2_sha256$120000$ybnEf26FolQ7$uAlyyV1CK0jE9TgxTuYnUEp9qdgabvueEtcF51/+Y/M=' ,'4@gmail.com',  NULL),
      (5, 5, 'pbkdf2_sha256$120000$BUGIfVYTF8xW$lL+bAHPStGV2dQeU/8YJrriFz6UE9AhKhKdGW/UGakE=' ,'statistic@gmail.com',  NULL),
      (6, 6, 'pbkdf2_sha256$120000$ybnEf26FolQ7$uAlyyV1CK0jE9TgxTuYnUEp9qdgabvueEtcF51/+Y/M=' ,'6@gmail.com',  NULL),
      (7, 7, 'pbkdf2_sha256$120000$ybnEf26FolQ7$uAlyyV1CK0jE9TgxTuYnUEp9qdgabvueEtcF51/+Y/M=' ,'7@gmail.com',  NULL),
      (8, 8, 'pbkdf2_sha256$120000$ybnEf26FolQ7$uAlyyV1CK0jE9TgxTuYnUEp9qdgabvueEtcF51/+Y/M=' ,'8@gmail.com',  NULL),
      (9, 9, 'pbkdf2_sha256$120000$ybnEf26FolQ7$uAlyyV1CK0jE9TgxTuYnUEp9qdgabvueEtcF51/+Y/M=' ,'jelysaw@gmail.com', NULL);