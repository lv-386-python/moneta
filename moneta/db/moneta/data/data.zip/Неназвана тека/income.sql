  File "/home/wm139/softserve/moneta/moneta/src/python/core/decorators.py", line 18, in inner
    return func(*args, **kwargs)
  File "/home/wm139/softserve/moneta/moneta/src/python/core/db/db_helper.py", line 28, in _make_select
    cursor.execute(sql_query, args)
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/MySQLdb/cursors.py", line 206, in execute
    res = self._query(query)
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/MySQLdb/cursors.py", line 312, in _query
    db.query(q)
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/MySQLdb/connections.py", line 224, in query
    _mysql.connection.query(self, query)
MySQLdb._exceptions.OperationalError: (1054, "Unknown column 'category' in 'where clause'")

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "manage.py", line 19, in <module>
    execute_from_command_line(sys.argv)
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/core/management/__init__.py", line 381, in execute_from_command_line
    utility.execute()
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/core/management/__init__.py", line 375, in execute
    self.fetch_command(subcommand).run_from_argv(self.argv)
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/core/management/base.py", line 316, in run_from_argv
    self.execute(*args, **cmd_options)
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/core/management/base.py", line 350, in execute
    self.check()
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/core/management/base.py", line 379, in check
    include_deployment_checks=include_deployment_checks,
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/core/management/base.py", line 366, in _run_checks
    return checks.run_checks(**kwargs)
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/core/checks/registry.py", line 71, in run_checks
    new_errors = check(app_configs=app_configs)
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/core/checks/urls.py", line 40, in check_url_namespaces_unique
    all_namespaces = _load_all_namespaces(resolver)
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/core/checks/urls.py", line 57, in _load_all_namespaces
    url_patterns = getattr(resolver, 'url_patterns', [])
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/utils/functional.py", line 37, in __get__
    res = instance.__dict__[self.name] = self.func(instance)
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/urls/resolvers.py", line 533, in url_patterns
    patterns = getattr(self.urlconf_module, "urlpatterns", self.urlconf_module)
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/utils/functional.py", line 37, in __get__
    res = instance.__dict__[self.name] = self.func(instance)
  File "/home/wm139/.pyenv/versions/moneta_virtualenv/lib/python3.7/site-packages/django/urls/resolvers.py", line 526, in urlconf_module
    return import_module(self.urlconf_name)
  File "/home/wm139/.pyenv/versions/3.7.2/lib/python3.7/importlib/__init__.py", line 127, in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
  File "<frozen importlib._bootstrap>", line 1006, in _gcd_import
  File "<frozen importlib._bootstrap>", line 983, in _find_and_load
  File "<frozen importlib._bootstrap>", line 967, in _find_and_load_unlocked
  File "<frozen importlib._bootstrap>", line 677, in _load_unlocked
  File "<frozen importlib._bootstrap_external>", line 728, in exec_module
  File "<frozen importlib._bootstrap>", line 219, in _call_with_frames_removed
  File "/home/wm139/softserve/moneta/moneta/www/settings/urls.py", line 18, in <module>
    from views import forgot_password, login_view, income, current, expend, \
  File "/home/wm139/softserve/moneta/moneta/www/views/income.py", line 13, in <module>
    from forms.income import AddIncomeForm, EditIncomeForm  # pylint:disable = no-name-in-module, import-error
  File "/home/wm139/softserve/moneta/moneta/www/forms/income.py", line 9, in <module>
    class AddIncomeForm(forms.Form):
  File "/home/wm139/softserve/moneta/moneta/www/forms/income.py", line 18, in AddIncomeForm
    choices=StorageIcon.get_icon_choices_by_category("income"),
  File "/home/wm139/softserve/moneta/moneta/src/python/db/storage_icon.py", line 36, in get_icon_choices_by_category
    icons = StorageIcon.get_icons(category)
  File "/home/wm139/softserve/moneta/moneta/src/python/db/storage_icon.py", line 25, in get_icons
    query = StorageIcon._make_select(sql, args)
  File "/home/wm139/softserve/moneta/moneta/src/python/core/decorators.py", line 21, in inner
    time.sleep(wait)
KeyboardInterrupt
