SOURCE schema/user.sql;
SOURCE schema/image.sql;
SOURCE schema/income.sql;
SOURCE schema/expend.sql;
SOURCE schema/current.sql;
SOURCE schema/user_income.sql;
SOURCE schema/user_expend.sql;
SOURCE schema/user_current.sql;
SOURCE schema/income_to_current.sql;
SOURCE schema/current_to_expend.sql;
SOURCE schema/current_to_current.sql;

